<?php
/**
 * View untuk halaman beranda
 * 
 * Menampilkan pesan selamat datang dan informasi dasar tentang aplikasi.
 * View ini akan dimasukkan ke dalam layout utama.
 */
?>
<!DOCTYPE html>
<html>
<body>
    <h1>Selamat Datang di Perpustakaan!</h1>
    <p>Silakan pilih menu di atas untuk mengelola buku perpustakaan.</p>
</body>
</html>